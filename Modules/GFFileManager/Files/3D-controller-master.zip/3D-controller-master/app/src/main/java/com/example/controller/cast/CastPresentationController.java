package com.example.controller.cast;

/**
 * Created by Hatem on 11-Apr-16.
 */
public interface CastPresentationController {
    void onButtonClick();
    void onSecondButtonClick();
    void pause();
    void resume();
}
